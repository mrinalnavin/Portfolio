import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { EducationComponent } from './education/education.component';
import { SkillsComponent } from './skills/skills.component';
import { ExperienceComponent } from './experience/experience.component';
import { ContactComponent } from './contact/contact.component';

const routes: Routes = [
    { path: 'Home', component: HomeComponent },
  { path: 'Education', component: EducationComponent },
  {path:'Skills',component:SkillsComponent},
  {path:'Experience',component:ExperienceComponent},
  {path:'Contact',component:ContactComponent},
  {path: '', redirectTo: '/Home', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
